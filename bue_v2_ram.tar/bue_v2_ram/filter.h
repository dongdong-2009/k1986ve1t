#ifndef _FILTER_H
#define _FILTER_H

#define RF_A11 4096
#define RF_A12 -7968
#define RF_A13 3899

#define RF_B11 4054
#define RF_B12 -7968
#define RF_B13 3942

#define RF_A21 4096
#define RF_A22 -7237
#define RF_A23 3199

#define RF_B21 3849
#define RF_B22 -7237
#define RF_B23 3446

#define RF_SHIFT 12

#endif
