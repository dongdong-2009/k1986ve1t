#ifndef _GDEF_H
#define _GDEF_H

#define BUF_SIZE 			8*1024
#define BUF_TH_DOWN 	7500
#define BUF_TH_UP 		7000

#endif
